# 📊 Telegram Bot Token Master

**All-in-one web tool untuk mengelola, membersihkan, dan memonitor token bot Telegram secara realtime.**

---

## ✨ Fitur Utama

| Menu | Fungsi |
|------|--------|
| **🧹 Token Cleaner** | Validasi otomatis, hapus token invalid & duplikat, export hasil bersih |
| **⚙️ Token Manager** | Tambah/hapus token, sync langsung ke GitHub via REST API |
| **📊 Dashboard Monitor** | Statistik realtime, skor keamanan, efisiensi, AI rekomendasi |

---

## 🔧 Tech Stack

- **Frontend**: 1 file HTML (inline CSS + JS)
- **Backend**: Express + REST API
- **Storage**: Local JSON + opsional GitHub sync
- **Dependency**: `cors`, `dotenv`, `express`

---

## 📦 Instalasi

1. **Clone / salin folder**
   ```bash
   mkdir telegram-token-master && cd telegram-token-master
   ```

2. **Install dependencies**
   ```bash
   npm install
   ```

3. **Konfigurasi Environment**  
   Buat file `.env` di root:
   ```env
   GITHUB_TOKEN=ghp_xxxxxxxxxxxxxxxxxxxx
   GITHUB_OWNER=your-github-username
   GITHUB_REPO=your-repo-name
   GITHUB_FILE_PATH=tokens.json
   PORT=3000
   ```

4. **Jalankan server**
   ```bash
   npm run dev     # dengan nodemon (auto-reload)
   # atau
   npm start       # production
   ```

5. **Buka browser**
   ```
   http://localhost:3000
   ```

---

## 🧭 Panduan Cepat

### 1. Token Cleaner
- Paste daftar token (JSON atau plain text)
- Klik **Analisis** → otomatis detect valid/invalid/duplikat
- Klik **Bersihkan** → hapus invalid & duplikat
- Klik **Export** → simpan hasil bersih sebagai JSON

### 2. Token Manager
- Klik **Reload** → ambil token dari server
- Tambah token baru (auto-validasi format)
- Hapus token individual
- Klik **Sync ke GitHub** → push/update file langsung ke repo

### 3. Dashboard Monitor
- Klik **Refresh** → muat ulang data & grafik
- Lihat statistik: total, valid, invalid, duplikat, skor keamanan, efisiensi
- Baca AI rekomendasi → langkah optimasi otomatis
- Klik **Export Laporan** → JSON lengkap + saran

---

## 📡 REST API Endpoint

| Method | Endpoint | Body | Kegunaan |
|--------|----------|------|----------|
| GET | `/api/tokens` | - | Ambil semua token |
| POST | `/api/tokens` | `{token}` | Tambah token baru |
| DELETE | `/api/tokens` | `{token}` | Hapus token |
| POST | `/api/sync-github` | `{tokens}` | Push ke GitHub |

---

## 📋 Format Token Benar

```
123456789:AAHGNECkoB4Y4YcrwhAO1nTS2WXG0RwmIEw
```
- **digits** : `123456789`
- **key** : `AAHGNECkoB4Y4YcrwhAO1nTS2WXG0RwmIEw`

---

## 🛡️ Keamanan

- Token tidak perlu dihash (sudah aman di backend)
- Gunakan **GitHub Personal Access Token** dengan scope `repo`
- Jangan push `.env` ke repository

---

## 📤 Export Hasil

Semua menu support export JSON:
- **Token Cleaner** → `cleaned-tokens-{timestamp}.json`
- **Dashboard** → `dashboard-report-{timestamp}.json`

Struktur export:
```json
{
  "tokens": ["123:ABC...", "456:DEF..."],
  "exported_at": "2026-01-13T12:34:56.789Z",
  "summary": { "total": 2, "valid": 2, "invalid": 0, "duplicates": 0 },
  "recommendations": ["Koleksi token Anda sudah optimal."]
}
```

---

## 🔄 Auto-create Database

File `database.json` otomatis dibuat saat pertama kali server dijalankan:
```json
{
  "tokens": [],
  "history": []
}
```

---

## ⚡ Tips

- Bersihkan token **mingguan** untuk menjaga efisiensi
- Sync ke GitHub setelah cleaning agar backup selalu update
- Perhatikan **Skor Keamanan** & **Efisiensi** di dashboard
- Ikuti **AI Rekomendasi** untuk optimasi otomatis

---

## 📄 Lisensi

Freeware — bebas digunakan untuk project pribadi maupun komersial.