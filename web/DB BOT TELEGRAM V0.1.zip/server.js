require('dotenv').config();
const express = require('express');
const cors = require('cors');
const fs = require('fs').promises;
const path = require('path');

const app = express();
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

const DB_FILE = path.join(__dirname, 'database.json');
const ENV = {
    GITHUB_TOKEN: process.env.GITHUB_TOKEN,
    GITHUB_OWNER: process.env.GITHUB_OWNER,
    GITHUB_REPO: process.env.GITHUB_REPO,
    GITHUB_FILE_PATH: process.env.GITHUB_FILE_PATH || 'tokens.json',
    PORT: process.env.PORT || 3000
};

// Auto-create empty database if not exists
async function initDB() {
    try {
        await fs.access(DB_FILE);
    } catch {
        const emptyDB = { tokens: [], history: [] };
        await fs.writeFile(DB_FILE, JSON.stringify(emptyDB, null, 2));
    }
}

// GET /api/tokens → return all tokens
app.get('/api/tokens', async (req, res) => {
    try {
        const raw = await fs.readFile(DB_FILE, 'utf-8');
        const db = JSON.parse(raw);
        res.json(db.tokens);
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST /api/tokens → add new token
app.post('/api/tokens', async (req, res) => {
    try {
        const { token } = req.body;
        if (!token || !/^\d+:[A-Za-z0-9_-]+$/.test(token)) {
            return res.status(400).json({ error: 'Invalid token format' });
        }

        const raw = await fs.readFile(DB_FILE, 'utf-8');
        const db = JSON.parse(raw);

        if (db.tokens.includes(token)) {
            return res.status(409).json({ error: 'Token already exists' });
        }

        db.tokens.push(token);
        db.history.push({ action: 'add', token: token.substring(0, 15) + '...', date: new Date().toISOString() });

        await fs.writeFile(DB_FILE, JSON.stringify(db, null, 2));
        res.json({ success: true, total: db.tokens.length });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// DELETE /api/tokens → remove token
app.delete('/api/tokens', async (req, res) => {
    try {
        const { token } = req.body;
        const raw = await fs.readFile(DB_FILE, 'utf-8');
        const db = JSON.parse(raw);

        const before = db.tokens.length;
        db.tokens = db.tokens.filter(t => t !== token);
        if (db.tokens.length === before) {
            return res.status(404).json({ error: 'Token not found' });
        }

        db.history.push({ action: 'remove', token: token.substring(0, 15) + '...', date: new Date().toISOString() });
        await fs.writeFile(DB_FILE, JSON.stringify(db, null, 2));

        res.json({ success: true, total: db.tokens.length });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// POST /api/sync-github → push ke GitHub
app.post('/api/sync-github', async (req, res) => {
    try {
        const { tokens } = req.body;
        const apiUrl = `https://api.github.com/repos/${ENV.GITHUB_OWNER}/${ENV.GITHUB_REPO}/contents/${ENV.GITHUB_FILE_PATH}`;

        // Get existing SHA jika file sudah ada
        let sha = '';
        const getRes = await fetch(apiUrl, {
            headers: { Authorization: `token ${ENV.GITHUB_TOKEN}` }
        });
        if (getRes.ok) {
            const json = await getRes.json();
            sha = json.sha;
        }

        const content = {
            tokens,
            updated_at: new Date().toISOString(),
            total_tokens: tokens.length
        };
        const contentBase64 = btoa(JSON.stringify(content, null, 2));

        const putRes = await fetch(apiUrl, {
            method: 'PUT',
            headers: {
                Authorization: `token ${ENV.GITHUB_TOKEN}`,
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                message: `Sync tokens: ${tokens.length} total`,
                content: contentBase64,
                sha
            })
        });

        if (!putRes.ok) {
            const err = await putRes.json();
            throw new Error(err.message);
        }

        res.json({ success: true, message: 'Synced to GitHub' });
    } catch (err) {
        res.status(500).json({ error: err.message });
    }
});

// Start server
(async () => {
    await initDB();
    app.listen(ENV.PORT, () => {
        console.log(`🚀 Telegram Token Master running at http://localhost:${ENV.PORT}`);
    });
})();