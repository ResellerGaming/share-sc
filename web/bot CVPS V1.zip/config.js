module.exports = {
    // Telegram Bot Token dari @BotFather
    telegramToken: 'YOUR_TELEGRAM_BOT_TOKEN',
    
    // DigitalOcean API Token (api do lu bang)
    digitalOceanToken: 'YOUR_DIGITALOCEAN_API_TOKEN',
    
    // Informasi Akun DigitalOcean (bebas mau di isi/gausah
    accountEmail: 'your-email@example.com',
    
    // User ID Telegram yang diizinkan (opsional - kosongkan untuk allow all)
    allowedUsers: [YOUR_TELEGRAM_USER_ID],
    
    // Regional Preferences only
    region: 'sgp1', // Region Singapore only
    
    // SSH Key ID (opsional - kosongkan jika tidak pakai SSH Key)
    sshKeyIds: [],
    backups: false,
    monitoring: true,
    

    pterodactyl: {
        defaultUser: 'admin',
        defaultEmail: 'admin@example.com',
        defaultLocation: 'SGP',
        defaultLocationDesc: 'Singapore Datacenter'
    }
};