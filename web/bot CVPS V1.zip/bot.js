const { Telegraf, Markup } = require('telegraf');
const axios = require('axios');
const crypto = require('crypto');
const { Client } = require('ssh2');
const config = require('./config');

const bot = new Telegraf(config.telegramToken);


const doApi = axios.create({
    baseURL: 'https://api.digitalocean.com/v2',
    headers: {
        'Authorization': `Bearer ${config.digitalOceanToken}`,
        'Content-Type': 'application/json'
    }
});


const userStates = new Map();
const pendingInstalls = new Map();

// Generate Random Password
function generatePassword(length = 12) {
    return crypto.randomBytes(length).toString('base64').slice(0, length);
}

// Generate Readable String
function generateReadableString(length = 4) {
    const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    let result = '';
    for (let i = 0; i < length; i++) {
        result += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    return result;
}

// Check if user is allowed
function isAllowed(userId) {
    if (config.allowedUsers.length === 0) return true;
    return config.allowedUsers.includes(userId);
}

// Logging functions
function logInstall(type, message) {
    console.log(`[${new Date().toISOString()}] [${type}] ${message}`);
}

function logError(type, message) {
    console.error(`[${new Date().toISOString()}] [${type}] ERROR: ${message}`);
}

// Edit reply helper
async function editReply(chatId, messageId, text, extra = {}) {
    try {
        await bot.telegram.editMessageText(chatId, messageId, null, text, extra);
    } catch (error) {
        console.error('Error editing message:', error.message);
    }
}

// Get Available OS Images
async function getAvailableOS() {
    try {
        const response = await doApi.get('/images?type=distribution&per_page=100');
        const images = response.data.images;
        
        // Filter untuk OS populer
        const popularOS = images.filter(img => 
            img.slug && (
                img.slug.includes('ubuntu-20') ||
                img.slug.includes('ubuntu-22') ||
                img.slug.includes('debian-11') ||
                img.slug.includes('debian-12') ||
                img.slug.includes('centos-7') ||
                img.slug.includes('centos-stream-8') ||
                img.slug.includes('rockylinux-8') ||
                img.slug.includes('rockylinux-9')
            )
        );
        
        return popularOS.slice(0, 8); // Batasi sampai 8 pilihan
    } catch (error) {
        console.error('Error getting OS images:', error.message);
        return [];
    }
}

// RAM Configuration
const ramConfigs = [
    { id: '1', name: 'RAM 1 Core 1 AMD', slug: 's-1vcpu-1gb-amd', price: '$4/mo' },
    { id: '2', name: 'RAM 2 Core 2 AMD', slug: 's-2vcpu-2gb-amd', price: '$12/mo' },
    { id: '3', name: 'RAM 4 Core 2 AMD', slug: 's-4vcpu-2gb-amd', price: '$24/mo' },
    { id: '4', name: 'RAM 8 Core 4 AMD', slug: 's-8vcpu-4gb-amd', price: '$48/mo' },
    { id: '5', name: 'RAM 16 Core 4 AMD', slug: 's-16vcpu-4gb-amd', price: '$96/mo' },
    { id: '6', name: 'RAM 16 Core 8 AMD', slug: 's-16vcpu-8gb-amd', price: '$192/mo' }
];

// Install Panel Function 
async function installPterodactylPanel(context) {
    const { xy, reply } = context;
    const userId = xy.from.id;
    const pending = pendingInstalls.get(userId);
    
    if (!pending || pending.command !== 'installpanel') {
        return reply('❌ Sesi instalasi tidak ditemukan. Gunakan /installpanel untuk memulai.');
    }
    
    const { ip: vpsIP, password: vpsPassword, domainPanel, domainNode, ram: ramserver } = pending.data;
    
    const sentMessage = await reply(`<blockquote>⚡ <b>INSTALL PANEL</b>

📋 <b>Konfigurasi:</b>
• IP: <code>${vpsIP}</code>
• Domain Panel: <code>${domainPanel}</code>
• Domain Node: <code>${domainNode}</code>
• RAM: <code>${ramserver} MB</code>

🔄 <b>Memulai proses instalasi...</b>

⏳ Ini akan memakan waktu 15-30 menit</blockquote>`, { parse_mode: 'HTML' });

    // Lanjutkan proses instalasi SSH
    (async () => {
        const ssh = new Client();
        const connSettings = { host: vpsIP, port: 22, username: 'root', password: vpsPassword };
        let connectionError = null;
        
        const user = config.pterodactyl.defaultUser + generateReadableString(4); 
        const pass = "Resming" + generateReadableString(6); 
        
        const commandPanel = `bash <(curl -s https://pterodactyl-installer.se)`;
        const commandCreateNode = `bash <(curl -s https://raw.githubusercontent.com/Bangsano/Autoinstaller-Theme-Pterodactyl/main/createnode.sh)`;
    
        try {
            logInstall('PANEL', `Connecting to ${vpsIP}...`);
            
            await new Promise((resolve, reject) => {
                ssh.on('ready', resolve).on('error', reject).connect(connSettings);
            });
            
            // --- 1. Install Panel ---
            logInstall('PANEL', 'Step 1: Installing Panel...');
            await editReply(xy.chat.id, sentMessage.message_id, `<blockquote>🔄 <b>[1/4] Menginstal Panel...</b>

⏳ Tunggu 5-10 menit</blockquote>`);
            
            await new Promise((resolve, reject) => {
                ssh.exec(commandPanel, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve); 
                    stream.on('data', (data) => {
                        const strData = data.toString();
                        logInstall('PANEL', strData.trim());
                        
                        if (strData.includes('Input 0-6')) stream.write('0\n');
                        else if (strData.includes('Database name')) stream.write('\n'); 
                        else if (strData.includes('Database username')) stream.write('\n'); 
                        else if (strData.includes('Password')) stream.write('\n');
                        else if (strData.includes('Select timezone')) {
                            stream.write('Asia/Jakarta\n'); 
                            stream.write(`${config.pterodactyl.defaultEmail}\n`);
                            stream.write(`${config.pterodactyl.defaultEmail}\n`);
                            stream.write(`${user}\n`);
                            stream.write(config.pterodactyl.defaultUser + '\n');
                            stream.write(config.pterodactyl.defaultUser + '\n');
                            stream.write(`${pass}\n`);
                            stream.write(`${domainPanel}\n`);
                        }
                        else if (strData.includes('(y/N)') || strData.includes('(Y)es/(N)o')) stream.write('y\n');
                        else if (strData.includes('Set the FQDN')) stream.write(`${domainPanel}\n`);
                    });
                    stream.stderr.on('data', (data) => logError('installpanel', data.toString()));
                });
            });

            // --- 2. Install Wings ---
            logInstall('PANEL', 'Step 2: Installing Wings...');
            await editReply(xy.chat.id, sentMessage.message_id, `<blockquote>✅ Panel OK!

🔄 <b>[2/4] Menginstal Wings...</b></blockquote>`);

            await new Promise((resolve, reject) => {
                ssh.exec(commandPanel, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve);
                    stream.on('data', (data) => {
                        const strData = data.toString();
                        logInstall('WINGS', strData.trim());
                        
                        if (strData.includes('Input 0-6')) stream.write('1\n');
                        else if (strData.includes('Enter the panel address')) stream.write(`https://${domainPanel}\n`);
                        else if (strData.includes('Database host username')) stream.write(`${user}\n`);
                        else if (strData.includes('Database host password') || strData.includes('Password')) stream.write(`${pass}\n`);
                        else if (strData.includes('Set the FQDN')) stream.write(`${domainNode}\n`);
                        else if (strData.includes('Enter email address')) stream.write(`${config.pterodactyl.defaultEmail}\n`);
                        else if (strData.includes('(y/N)') || strData.includes('(Y)es/(N)o') || strData.includes('Continue with installation? (y/N)')) {
                            stream.write('y\n');
                        }
                    });
                    stream.stderr.on('data', (data) => logError('installwings', data.toString()));
                });
            });

            // --- 3. Create Node ---
            logInstall('PANEL', 'Step 3: Creating Node...');
            await editReply(xy.chat.id, sentMessage.message_id, `<blockquote>✅ Wings OK!

🔄 <b>[3/4] Membuat Node...</b></blockquote>`);

            await new Promise((resolve, reject) => {
                ssh.exec(commandCreateNode, (err, streamNode) => {
                    if (err) return reject(err);
                    streamNode.on('close', resolve);
                    streamNode.on('data', (data) => {
                        const output = data.toString();
                        logInstall('CREATENODE', output.trim());
                        
                        if (output.includes("Masukkan nama lokasi: ")) streamNode.write(`${config.pterodactyl.defaultLocation}\n`);
                        else if (output.includes("Masukkan deskripsi lokasi: ")) streamNode.write(`${config.pterodactyl.defaultLocationDesc}\n`);
                        else if (output.includes("Masukkan domain: ")) streamNode.write(`${domainNode}\n`);
                        else if (output.includes("Masukkan nama node: ")) streamNode.write('NODE BY BOT\n');
                        else if (output.includes("Masukkan RAM (dalam MB): ")) streamNode.write(`${ramserver}\n`);
                        else if (output.includes("Masukkan jumlah maksimum disk space (dalam MB): ")) streamNode.write(`${ramserver * 2}\n`);
                        else if (output.includes("Masukkan Locid: ")) streamNode.write('1\n');
                    });
                    streamNode.stderr.on('data', (data) => logError('createnode', data.toString()));
                });
            });

            // --- 4. Start Wings ---
            logInstall('PANEL', 'Step 4: Starting Wings...');
            await editReply(xy.chat.id, sentMessage.message_id, `<blockquote>✅ Node OK!

🔄 <b>[4/5] Menjalankan Wings...</b></blockquote>`);
            
            await new Promise((resolve, reject) => {
                ssh.exec('systemctl start wings', (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', resolve);
                    stream.on('data', (data) => logInstall('STARTWINGS', data.toString().trim()));
                    stream.stderr.on('data', (data) => logError('startwings', data.toString()));
                });
            });

            // --- 5. Configure Wings config.yml (PRO) ---
            logInstall('PANEL', 'Step 5: Configuring Wings config.yml (PRO)...');
            await editReply(
                xy.chat.id,
                sentMessage.message_id,
                `<blockquote>🚀 Wings Started!

🔄 <b>[5/5] Configuring config.yml (PRO MODE)...</b></blockquote>`
            );

            const wait = ms => new Promise(r => setTimeout(r, ms));

            const run = (cmd, tag) => new Promise((resolve, reject) => {
                ssh.exec(cmd, (err, stream) => {
                    if (err) return reject(err);
                    stream.on('close', () => resolve());
                    stream.on('data', d => logInstall(tag, d.toString().trim()));
                    stream.stderr.on('data', d => logError(tag, d.toString()));
                });
            });

            // tunggu panel + SSL benar-benar siap
            await wait(15000);

            const genCfg = `
            cd /var/www/pterodactyl &&
            php artisan p:node:configuration 1 --no-ansi > /etc/pterodactyl/config.yml &&
            chown root:root /etc/pterodactyl/config.yml &&
            chmod 600 /etc/pterodactyl/config.yml
            `;

            logInstall('WINGS', 'Generate config (1)');
            await run(genCfg, 'CONFIG1');

            await run('systemctl restart wings', 'WINGS');
            await wait(8000);

            logInstall('WINGS', 'Generate config (2)');
            await run(genCfg, 'CONFIG2');

            await run('systemctl restart wings', 'WINGS');
            await wait(5000);

            await run('systemctl is-active wings', 'HEALTH');

            logInstall('PANEL', '✅ Wings configured — node should be GREEN');

            logInstall('PANEL', 'Installation completed successfully!');
            
            const finalMessage = `<blockquote>
✅ <b>INSTALASI SELESAI!</b>

🌐 <b>Panel:</b> https://${domainPanel}
🖥️ <b>Node:</b> ${domainNode}

👤 <b>Username:</b> <code>${user}</code>
🔐 <b>Password:</b> <code>${pass}</code>

💡 Simpan kredensial ini dengan aman!
</blockquote>`;
            await editReply(xy.chat.id, sentMessage.message_id, finalMessage);

        } catch (err) {
            connectionError = err;
            logError('installpanel', err.message);
        } finally {
            ssh.end();
        }

        if (connectionError) {
            await editReply(xy.chat.id, sentMessage.message_id, `<blockquote>❌ Gagal: ${connectionError.message || 'Koneksi SSH gagal.'}</blockquote>`);
        }
        
        // Hapus pending install setelah selesai
        pendingInstalls.delete(userId);
    })();
}

// Handle Install Panel Command
bot.command('installpanel', async (ctx) => {
    if (!isAllowed(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses ke bot ini.');
    }
    
    const userId = ctx.from.id;
    const pending = pendingInstalls.get(userId);
    
    // Step 1: Minta IP VPS
    if (!pending || pending.command !== 'installpanel') {
        pendingInstalls.set(userId, {
            command: 'installpanel',
            step: 'waiting_ip',
            data: {},
            timestamp: Date.now()
        });
        
        return ctx.reply(`<blockquote>⚡ <b>INSTALL PANEL</b>

📝 <b>Step 1/5:</b> Masukkan IP VPS

Contoh: <code>192.168.1.1</code>

⚠️ Ketik /cancel untuk membatalkan</blockquote>`, { parse_mode: 'HTML' });
    }
});

// Create VPS Command
bot.command('cvps', async (ctx) => {
    if (!isAllowed(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses ke bot ini.');
    }
    
    userStates.set(ctx.from.id, { step: 'hostname' });
    
    ctx.reply(`
🖥️ *Buat VPS Baru*

Langkah 1 dari 3
Silakan masukkan hostname untuk VPS Anda:
(Contoh: my-server, web-server-01)

Ketik /cancel untuk membatalkan.
    `, { parse_mode: 'Markdown' });
});

// Status Command
bot.command('statusdo', async (ctx) => {
    if (!isAllowed(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses ke bot ini.');
    }
    
    try {
        // Get account info
        const accountResponse = await doApi.get('/account');
        const account = accountResponse.data.account;
        
        // Get droplets info
        const dropletsResponse = await doApi.get('/droplets');
        const droplets = dropletsResponse.data.droplets;
        
        const activeDroplets = droplets.filter(d => d.status === 'active').length;
        const totalDroplets = droplets.length;
        
        const statusMessage = `
📊 *Status Akun DigitalOcean*

📧 *Email:* ${account.email}
🔑 *Droplet Status:* ${account.droplet_limit > 0 ? '✅ Aktif' : '❌ Tidak Aktif'}
📈 *Droplet Digunakan:* ${activeDroplets} / ${account.droplet_limit}
📉 *Sisa Droplet:* ${account.droplet_limit - activeDroplets}
🔢 *Total Droplet:* ${totalDroplets}

💰 *Status Pembayaran:* ${account.status}
        `;
        
        ctx.reply(statusMessage, { parse_mode: 'Markdown' });
        
    } catch (error) {
        console.error('Error getting status:', error.message);
        ctx.reply('❌ Terjadi kesalahan saat mengambil status akun. Pastikan API token valid.');
    }
});

// Start Command
bot.start((ctx) => {
    if (!isAllowed(ctx.from.id)) {
        return ctx.reply('❌ Anda tidak memiliki akses ke bot ini.');
    }
    
    const welcomeMessage = `
🌊 *DigitalOcean VPS Bot*

Halo ${ctx.from.first_name}! 
Bot ini membantu Anda membuat dan mengelola VPS di DigitalOcean.

📋 *Daftar Perintah:*
• /cvps - Buat VPS baru
• /statusdo - Cek status akun DigitalOcean
• /installpanel - Install Pterodactyl Panel
• /help - Bantuan

⚡ *Powered by DigitalOcean API*
    `;
    
    ctx.reply(welcomeMessage, { parse_mode: 'Markdown' });
});

// Help Command
bot.help((ctx) => {
    const helpMessage = `
📖 *Bantuan DigitalOcean VPS Bot*

🔧 *Perintah VPS:*
• /cvps - Membuat VPS baru
  - Masukkan hostname
  - Pilih OS dari tombol
  - Pilih konfigurasi RAM dari tombol

• /statusdo - Menampilkan status akun
  - Email akun
  - Jumlah droplet yang digunakan
  - Sisa droplet yang bisa dibuat
  - Total droplet

🎮 *Perintah Panel Game:*
• /installpanel - Install Pterodactyl Panel
  - 5 step wizard: IP, Password, Domain Panel, Domain Node, RAM
  - Otomatis install Panel + Wings + Node
  - Generate kredensial admin

💡 *Tips:*
- Password root akan di-generate otomatis
- VPS akan dibuat di region Singapore (sgp1)
- Monitoring otomatis aktif
- Install panel membutuhkan waktu 15-30 menit
    `;
    
    ctx.reply(helpMessage, { parse_mode: 'Markdown' });
});

// Cancel Command
bot.command('cancel', (ctx) => {
    const userId = ctx.from.id;
    
    // Cancel VPS creation
    if (userStates.has(userId)) {
        userStates.delete(userId);
        ctx.reply('✅ Pembuatan VPS dibatalkan.');
    }
    
    // Cancel panel installation
    if (pendingInstalls.has(userId)) {
        pendingInstalls.delete(userId);
        ctx.reply('✅ Instalasi panel dibatalkan.');
    }
    
    if (!userStates.has(userId) && !pendingInstalls.has(userId)) {
        ctx.reply('ℹ️ Tidak ada proses yang berjalan.');
    }
});

// Handle Text Messages
bot.on('text', async (ctx) => {
    if (!isAllowed(ctx.from.id)) return;
    
    const userId = ctx.from.id;
    const text = ctx.message.text.trim();
    
    // Handle Install Panel Messages
    const pending = pendingInstalls.get(userId);
    if (pending && pending.command === 'installpanel') {
        // Step 2: IP diterima, minta Password
        if (pending.step === 'waiting_ip') {
            if (!text || !/^[\d.]+$/.test(text)) {
                return ctx.reply(`<blockquote>❌ Format IP tidak valid! Masukkan IP VPS yang benar.

⚠️ Ketik /cancel untuk membatalkan</blockquote>`, { parse_mode: 'HTML' });
            }
            
            pending.data.ip = text;
            pending.step = 'waiting_password';
            pendingInstalls.set(userId, pending);
            
            return ctx.reply(`<blockquote>⚡ <b>INSTALL PANEL</b>

✅ IP: <code>${pending.data.ip}</code>

📝 <b>Step 2/5:</b> Masukkan Password VPS

⚠️ Ketik /cancel untuk membatalkan</blockquote>`, { parse_mode: 'HTML' });
        }
        
        // Step 3: Password diterima, minta Domain Panel
        if (pending.step === 'waiting_password') {
            pending.data.password = text;
            pending.step = 'waiting_domain_panel';
            pendingInstalls.set(userId, pending);
            
            return ctx.reply(`<blockquote>⚡ <b>INSTALL PANEL</b>

✅ IP: <code>${pending.data.ip}</code>
✅ Password: ••••••••

📝 <b>Step 3/5:</b> Masukkan Domain Panel

Contoh: <code>panel.domain.com</code>

⚠️ Ketik /cancel untuk membatalkan</blockquote>`, { parse_mode: 'HTML' });
        }
        
        // Step 4: Domain Panel diterima, minta Domain Node
        if (pending.step === 'waiting_domain_panel') {
            pending.data.domainPanel = text;
            pending.step = 'waiting_domain_node';
            pendingInstalls.set(userId, pending);
            
            return ctx.reply(`<blockquote>⚡ <b>INSTALL PANEL</b>

✅ IP: <code>${pending.data.ip}</code>
✅ Password: ••••••••
✅ Domain Panel: <code>${pending.data.domainPanel}</code>

📝 <b>Step 4/5:</b> Masukkan Domain Node

Contoh: <code>node.domain.com</code>

⚠️ Ketik /cancel untuk membatalkan</blockquote>`, { parse_mode: 'HTML' });
        }
        
        // Step 5: Domain Node diterima, minta RAM
        if (pending.step === 'waiting_domain_node') {
            pending.data.domainNode = text;
            pending.step = 'waiting_ram';
            pendingInstalls.set(userId, pending);
            
            return ctx.reply(`<blockquote>⚡ <b>INSTALL PANEL</b>

✅ IP: <code>${pending.data.ip}</code>
✅ Password: ••••••••
✅ Domain Panel: <code>${pending.data.domainPanel}</code>
✅ Domain Node: <code>${pending.data.domainNode}</code>

📝 <b>Step 5/5:</b> Masukkan RAM (dalam MB)

Contoh: <code>4096</code> (untuk 4GB RAM)

⚠️ Ketik /cancel untuk membatalkan</blockquote>`, { parse_mode: 'HTML' });
        }
        
        // Step Final: RAM diterima, mulai instalasi
        if (pending.step === 'waiting_ram') {
            pending.data.ram = text;
            
            const context = {
                xy: ctx,
                isOwner: true,
                reply: ctx.reply.bind(ctx),
                mess: { owner: '❌ Anda bukan owner!' },
                text: text,
                command: 'installpanel',
                generateReadableString: generateReadableString,
                prefix: '/'
            };
            
            // Mulai instalasi
            installPterodactylPanel(context);
            return;
        }
    }
    
    // Handle VPS Creation Messages
    const userState = userStates.get(userId);
    if (!userState) return;
    
    switch (userState.step) {
        case 'hostname':
            const hostname = text;
            
            if (hostname.length < 3 || hostname.length > 50) {
                return ctx.reply('❌ Hostname harus antara 3-50 karakter. Silakan coba lagi.');
            }
            
            if (!/^[a-zA-Z0-9-]+$/.test(hostname)) {
                return ctx.reply('❌ Hostname hanya boleh mengandung huruf, angka, dan tanda strip (-).');
            }
            
            userState.hostname = hostname;
            userState.step = 'select_os';
            
            // Get available OS
            const osImages = await getAvailableOS();
            
            if (osImages.length === 0) {
                return ctx.reply('❌ Tidak dapat mengambil daftar OS. Silakan coba lagi nanti.');
            }
            
            const osButtons = osImages.map(os => 
                Markup.button.callback(`${os.distribution} ${os.name}`, `os_${os.slug}`)
            );
            
            ctx.reply(
                '🖥️ *Pilih Sistem Operasi:*\n\nLangkah 2 dari 3',
                {
                    parse_mode: 'Markdown',
                    ...Markup.inlineKeyboard(osButtons, { columns: 2 })
                }
            );
            break;
    }
});

// Handle OS Selection
bot.action(/^os_(.+)$/, async (ctx) => {
    if (!isAllowed(ctx.from.id)) return;
    
    const osSlug = ctx.match[1];
    const userId = ctx.from.id;
    const userState = userStates.get(userId);
    
    if (!userState || userState.step !== 'select_os') {
        return ctx.answerCbQuery('❌ Sesi telah berakhir. Silakan mulai dari /cvps');
    }
    
    userState.osSlug = osSlug;
    userState.step = 'select_ram';
    
    // Create RAM buttons
    const ramButtons = ramConfigs.map(config => 
        Markup.button.callback(
            `${config.name} (${config.price})`, 
            `ram_${config.id}`
        )
    );
    
    await ctx.editMessageText(
        '💾 *Pilih Konfigurasi RAM:*\n\nLangkah 3 dari 3',
        {
            parse_mode: 'Markdown',
            ...Markup.inlineKeyboard(ramButtons, { columns: 1 })
        }
    );
    
    ctx.answerCbQuery();
});

// Handle RAM Selection and Create VPS
bot.action(/^ram_(.+)$/, async (ctx) => {
    if (!isAllowed(ctx.from.id)) return;
    
    const ramId = ctx.match[1];
    const userId = ctx.from.id;
    const userState = userStates.get(userId);
    
    if (!userState || userState.step !== 'select_ram') {
        return ctx.answerCbQuery('❌ Sesi telah berakhir. Silakan mulai dari /cvps');
    }
    
    const ramConfig = ramConfigs.find(r => r.id === ramId);
    if (!ramConfig) {
        return ctx.answerCbQuery('❌ Konfigurasi RAM tidak valid.');
    }
    
    userState.ramSlug = ramConfig.slug;
    
    // Create VPS
    try {
        await ctx.editMessageText('⏳ Sedang membuat VPS... Silakan tunggu.');
        
        // Generate password
        const rootPassword = generatePassword(16);
        
        // Create droplet
        const dropletData = {
            name: userState.hostname,
            region: config.region,
            size: userState.ramSlug,
            image: userState.osSlug,
            ssh_keys: config.sshKeyIds,
            backups: config.backups,
            monitoring: config.monitoring,
            user_data: `#!/bin/bash
echo "root:${rootPassword}" | chpasswd
apt-get update -y || yum update -y
`
        };
        
        const response = await doApi.post('/droplets', dropletData);
        const droplet = response.data.droplet;
        
        // Wait for IP address
        let ipAddress = null;
        let attempts = 0;
        
        while (!ipAddress && attempts < 30) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            
            const statusResponse = await doApi.get(`/droplets/${droplet.id}`);
            const updatedDroplet = statusResponse.data.droplet;
            
            if (updatedDroplet.networks.v4.length > 0) {
                ipAddress = updatedDroplet.networks.v4[0].ip_address;
            }
            attempts++;
        }
        
        if (!ipAddress) {
            return ctx.editMessageText('⚠️ VPS berhasil dibuat tetapi IP address belum tersedia. Silakan cek di dashboard DigitalOcean.');
        }
        
        const successMessage = `
✅ *VPS Berhasil Dibuat!*

📋 *Detail VPS:*
🖥️ *Hostname:* ${userState.hostname}
🌐 *IP Address:* ${ipAddress}
🔑 *Username:* root
🔒 *Password:* ||${rootPassword}||
💾 *RAM:* ${ramConfig.name}
🖥️ *OS:* ${userState.osSlug}

⚡ *Akses VPS:*
\`\`\`
ssh root@${ipAddress}
\`\`\`

📌 *Catatan:*
- Password di atas akan hilang setelah pesan ini ditutup
- Simpan password dengan aman
- VPS akan siap dalam 2-3 menit
        `;
        
        ctx.editMessageText(successMessage, { 
            parse_mode: 'Markdown',
            protect_content: true
        });
        
    } catch (error) {
        console.error('Error creating VPS:', error.response?.data || error.message);
        
        let errorMessage = '❌ Gagal membuat VPS. ';
        
        if (error.response?.data?.message) {
            errorMessage += `Error: ${error.response.data.message}`;
        } else {
            errorMessage += 'Silakan coba lagi.';
        }
        
        ctx.editMessageText(errorMessage);
    } finally {
        userStates.delete(userId);
    }
    
    ctx.answerCbQuery();
});


bot.catch((err, ctx) => {
    console.error(`Bot error for ${ctx.updateType}`, err);
    ctx.reply('❌ Terjadi kesalahan. Silakan coba lagi.');
});


console.log('🤖 DigitalOcean VPS Bot with Pterodactyl Installer starting...');
bot.launch();


process.once('SIGINT', () => bot.stop('SIGINT'));
process.once('SIGTERM', () => bot.stop('SIGTERM'));

console.log('✅ Bot berhasil dijalankan!');