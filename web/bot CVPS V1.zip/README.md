# DigitalOcean VPS & Pterodactyl Panel Telegram Bot

Bot Telegram untuk membuat VPS di DigitalOcean dan install Pterodactyl Panel secara otomatis.

## Fitur

### VPS Management
- ➕ Buat VPS baru dengan wizard interaktif
- 📊 Cek status akun DigitalOcean
- 🖥️ Pilihan OS lengkap (Ubuntu, Debian, CentOS, Rocky Linux)
- 💾 6 Pilihan konfigurasi RAM (1-16 core)
- 🔒 Password root otomatis generate
- 🌐 Akses langsung via SSH

### Pterodactyl Panel Installation
- 🎮 Install Pterodactyl Panel + Wings + Node
- 📋 Wizard 5 step: IP, Password, Domain Panel, Domain Node, RAM
- 🔧 Otomatis konfigurasi SSL dan database
- 👤 Generate kredensial admin otomatis
- ⚡ Proses instalasi 15-30 menit

## Instalasi

1. Clone repository
```bash
git clone https://github.com/yourusername/digitalocean-vps-bot.git
cd digitalocean-vps-bot