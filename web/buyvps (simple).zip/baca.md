Cara Makai 
1. Deploy di mana aja bisa/ localhost juga bisa
2. Wajib Ada Akun digital Ocean Dan buat apikey Digital Ocean (FULL ACCESS)
3. salin dan tempel lalu simpan di websitenya 
4. Dan pencet periksa status 
5. done keluar hasilnya 

INFORMASI 👤
Telegram Channel : https://t.me/codexengineer
WhatsApp Channel : https://whatsapp.com/channel/0029VbAt2GM7j6g6d13Xx01X
Kreator : Reseller Gaming (Owner)

© Reseller Gaming 