Cara Makai 
1. Deploy di mana aja bisa/ localhost juga bisa
2. Wajib Ada Akun akun github Dan buat token  clasiu (FULL ACCESS)
3. salin dan tempel lalu 
4. masukin username github nya dan simpan 
5. Done Tools Github siap digunakan 

INFORMASI 👤
Telegram Channel : https://t.me/codexengineer
WhatsApp Channel : https://whatsapp.com/channel/0029VbAt2GM7j6g6d13Xx01X
Kreator : Reseller Gaming (Owner)

💸 Donate Via Saweria
https://saweria.co/ahmadi02

REPORT VIA BOT TELEGRAM 
Username 
@repotcodexbot

© Reseller Gaming 