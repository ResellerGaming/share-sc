Cara Makai 
1. Deploy di mana aja bisa/ localhost juga bisa
2. Wajib Ada Akun akun api dan apikey anda, ke website api https://fgsi.dpdns.org/docs
3. Salin link yang ingin skip/bypass shortlink tersebut 
4. tempel apikey anda 
5. setelah itu pencet button "Bypass Link"
6. tunggu prosesnya, setelah lihat hasilnya akan menjadi link 
7. bisa disalin terus di tempel langsung web atau langsung pencet link nanti otomatis ke link tersebut.
8. Done dan terimakasih ☺️

INFORMASI 👤
Telegram Channel : https://t.me/codexengineer
WhatsApp Channel : https://whatsapp.com/channel/0029VbAt2GM7j6g6d13Xx01X
Kreator : Reseller Gaming (Owner)

💸 Donate Via Saweria
https://saweria.co/ahmadi02

REPORT VIA BOT TELEGRAM 
Username 
@repotcodexbot

© Reseller Gaming 